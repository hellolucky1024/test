import torch
import scipy.io as sio
import numpy as np
from torch.utils.data import Dataset
import pandas as pd

def get_data(data_file:str):
    data = sio.loadmat(data_file)
    # data = pd.read_csv(data_file)

    wendu = data['ddd'][:,0][:,np.newaxis]
    ludian = data['ddd'][:,1][:,np.newaxis]
    pressure = data['ddd'][:,2][:,np.newaxis]
    coldh = data['ddd'][:,3][:,np.newaxis]
    hoth = data['ddd'][:,4][:,np.newaxis]
    hotzhishu = data['ddd'][:,5][:,np.newaxis]
    coldzhishu = data['ddd'][:, 6][:, np.newaxis]
    fengspeed = data['ddd'][:, 7][:, np.newaxis]

    eleload = data['ddd'][:, 8][:, np.newaxis]
    coldload = data['ddd'][:, 9][:, np.newaxis]
    hotload = data['ddd'][:, 10][:, np.newaxis]

    return wendu, ludian, pressure, coldh, hoth, hotzhishu, coldzhishu, fengspeed, eleload, coldload, hotload

class LoadData(Dataset):
    def __init__(self, data_path, divide_points, history_length, train_mode):
        self.data_path = data_path
        self.train_mode = train_mode
        self.train_points = divide_points[0]
        self.test_points = divide_points[1]
        self.history_length = history_length
        self.wendu, self.ludian, self.pressure, self.coldh, self.hoth, self.hotzhishu, self.coldzhishu, self.fengspeed, self.eleload, self.coldload, self.hotload = get_data(data_path[0])

    def __len__(self):
        if self.train_mode == "train":
            return self.train_points - self.history_length
        elif self.train_mode == "test":
            return self.test_points
        else:
            raise ValueError("train mode: [{}] is not defined".format(self.train_mode))

    def __getitem__(self, index):
        if self.train_mode == "train":
            index = index
        elif self.train_mode == "test":
            index += self.train_points
        else:
            raise ValueError("train mode:[{}] is not defined".format(self.train_mode))

        wendu_x, wendu_y = LoadData.slice_data(self.wendu, self.history_length, index, self.train_mode)
        ludian_x, luidan_y = LoadData.slice_data(self.ludian, self.history_length, index, self.train_mode)
        pressure_x, pressure_y = LoadData.slice_data(self.pressure, self.history_length, index, self.train_mode)
        coldh_x ,  coldh_y = LoadData.slice_data(self.coldh, self.history_length, index, self.train_mode)
        hoth_x, hoth_y = LoadData.slice_data(self.hoth, self.history_length, index, self.train_mode)
        hotzhishu_x, hotzhishu_y = LoadData.slice_data(self.hotzhishu, self.history_length, index, self.train_mode)
        coldzhishu_x, coldzhishu_y = LoadData.slice_data(self.coldzhishu, self.history_length, index, self.train_mode)
        fengspeed_x, fengspeed_y = LoadData.slice_data(self.fengspeed, self.history_length, index, self.train_mode)
        eleload_x, eleload_y = LoadData.slice_data(self.eleload, self.history_length, index, self.train_mode)
        coldload_x, coldload_y = LoadData.slice_data(self.coldload, self.history_length, index, self.train_mode)
        hotload_x, hotload_y = LoadData.slice_data(self.hotload, self.history_length, index, self.train_mode)

        wendu_x = LoadData.to_tensor(wendu_x)
        ludian_x = LoadData.to_tensor(ludian_x)
        pressure_x = LoadData.to_tensor(pressure_x)
        coldh_x = LoadData.to_tensor(coldh_x)
        hoth_x = LoadData.to_tensor(hoth_x)
        hotzhishu_x = LoadData.to_tensor(hotzhishu_x)
        coldzhishu_x = LoadData.to_tensor(coldzhishu_x)
        fengspeed_x = LoadData.to_tensor(fengspeed_x)

        eleload_x = LoadData.to_tensor(eleload_x)
        coldload_x = LoadData.to_tensor(coldload_x)
        hotload_x = LoadData.to_tensor(hotload_x)

        eleload_y = LoadData.to_tensor(eleload_y)
        coldload_y = LoadData.to_tensor(coldload_y)
        hotload_y = LoadData.to_tensor(hotload_y)


        return {"wendu_x": wendu_x, "ludian_x": ludian_x, "pressure_x": pressure_x, "coldh_x":coldh_x, "hoth_x": hoth_x, "hotzhishu_x": hotzhishu_x, "coldzhishu_x": coldzhishu_x,"fengspeed_x": fengspeed_x, "eleload_x": eleload_x, "coldload_x": coldload_x, "hotload_x": hotload_x, "eleload_y": eleload_y, "coldload_y": coldload_y, "hotload_y": hotload_y,}

    @staticmethod#####电
    def slice_data(data, history_length, index, train_mode):
        if train_mode == "train":
            start_index = index
            end_index = index + history_length
        elif train_mode == "test":
            start_index = index - history_length
            end_index = index
        else:
            raise ValueError("train mode: [{}] is not defined".format(train_mode))
        data_x = data[start_index: end_index]
        data_y = data[end_index:end_index+1]
        return data_x, data_y


    @staticmethod
    def to_tensor(data):
        return torch.tensor(data, dtype=torch.float)

if __name__ == '__main__':
    train_data = LoadData(data_path=["data/data.mat"], divide_points=[96000, 10176],
                          history_length=8, train_mode="train")
#

    # print(train_data[1]["load_x"].size())
    # print(train_data[1]["mint_x"].size())
    # print(train_data[1]["load_y"].size())
    # print(train_data[1]["flow_y"])

