import os
import time
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
from load_data import LoadData
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams['font.family'] = 'STKAITI'  # 'STKAITI'——字体
plt.rcParams['axes.unicode_minus'] = False  # 解决坐标轴负数的负号显示问题

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#基于注意力机制的LSTM模型
class AttnLSTM(nn.Module):
    def __init__(self,input_size, hidden_size,num_layers):
        super(AttnLSTM, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=num_layers, batch_first=True)
        self.attention = nn.Linear(hidden_size, 1)
        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):
        lstm_out, _ = self.lstm(x)    # 输入LSTM层，得到隐状态lstm_out
        attn_weight = F.softmax(self.attention(lstm_out), dim=1)    # 计算注意力权重
        attn_out = torch.bmm(attn_weight.transpose(1, 2), lstm_out)    # 注意力加权
        out = self.fc(attn_out)    # 全连接层得到输出
        return out

class SkipLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, bidirectional):
        super(SkipLSTM, self).__init__()
        self.hidden_size = hidden_size
        # 原始的 LSTM 层
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, bidirectional)
        # 跳过门
        self.skip_gate = nn.Sequential(
            nn.Linear(hidden_size, 1),
            nn.Sigmoid(),
        )
        self.skip_length = 24

    def forward(self, inputs):
        outputs = []
        skip_states = []
        hidden_state = None
        for i in range(0, inputs.size(0), self.skip_length):
            output, hidden_state = self.lstm(inputs[i:i + self.skip_length], hidden_state)
            skip_vector = self.skip_gate(hidden_state[0])
            output = output * skip_vector
            outputs.append(output)
            skip_states.append(skip_vector)
        return torch.cat(outputs), torch.cat(skip_states)


class MSADNN(nn.Module):
    def __init__(self, channels=64, r=4, ):
        super(MSADNN, self, ).__init__()

        inter_channels = int(channels // r)

        ####气象特征全连接双层网络 8个维度特征
        self.wendu1 = nn.Linear(8, 32, bias=True)
        self.wendu2 = nn.Linear(32, 8, bias=True)

        self.ludian1 = nn.Linear(8, 32, bias=True)
        self.ludian2 = nn.Linear(32, 8, bias=True)

        self.pressure1 = nn.Linear(8, 32, bias=True)
        self.pressure2 = nn.Linear(32, 8, bias=True)

        self.coldh1 = nn.Linear(8, 32, bias=True)
        self.coldh2 = nn.Linear(32, 8, bias=True)

        self.hoth1 = nn.Linear(8, 32, bias=True)
        self.hoth2 = nn.Linear(32, 8, bias=True)

        self.hotzhishu1 = nn.Linear(8, 32, bias=True)
        self.hotzhishu2 = nn.Linear(32, 8, bias=True)

        self.coldzhishu1 = nn.Linear(8, 32, bias=True)
        self.coldzhishu2 = nn.Linear(32, 8, bias=True)

        self.fengspeed1 = nn.Linear(8, 32, bias=True)
        self.fengspeed2 = nn.Linear(32, 8, bias=True)

        ###做电冷热的各自特征加权 需要三个全连接分布
        self.F1 = F.softmax
        self.F2 = F.softmax
        self.F3 = F.softmax

        ####到这里 三类负荷已经有了气象特征的影响 下面加入不同周期下的数值融合，，，周期性需要根据前面用自相关分析做出来的添加 小时级别的预测 + 前几个小时的 +整天的？ 或者周期性问题只用来分析各类因素间的相互作用关系 这个地方只用单纯的日 周 等日期概念来增加概念

        # self.lstm_ele = nn.LSTM(input_size=5, hidden_size=8, num_layers=1)
        # self.lstm_cold = nn.LSTM(input_size=5, hidden_size=8, num_layers=1)
        # self.lstm_hot = nn.LSTM(input_size=5, hidden_size=8, num_layers=1)
        self.lstm_ele = AttnLSTM(input_size=5, hidden_size=8, num_layers=1)
        self.lstm_cold = AttnLSTM(input_size=5, hidden_size=8, num_layers=1)
        self.lstm_hot = AttnLSTM(input_size=5, hidden_size=8, num_layers=1)

        self.skiplstm = SkipLSTM(input_size=1, hidden_size=1, num_layers=1, bidirectional=True)

        self.fc1 = nn.Linear(8, 1)
        self.fc2 = nn.Linear(8, 1)
        self.fc3 = nn.Linear(8, 1)

        # self.conv1 = nn.Conv1d(8, 1, kernel_size=3, padding=1)
        # self.conv2 = nn.Conv1d(8, 1, kernel_size=3, padding=1)
        # self.conv3 = nn.Conv1d(8, 1, kernel_size=3, padding=1)

    def forward(self, data):
        eleload_x = data['eleload_x']
        coldload_x = data['coldload_x']
        hotload_x = data['hotload_x']

        wendu_x = data['wendu_x'].squeeze(2)
        wendu1 = self.wendu1(wendu_x)
        wendu2 = self.wendu2(wendu1).unsqueeze(2)

        ludian_x = data['ludian_x'].squeeze(2)
        ludian1 = self.ludian1(ludian_x)
        ludian2 = self.ludian2(ludian1).unsqueeze(2)

        pressure_x = data['pressure_x'].squeeze(2)
        pressure1 = self.pressure1(pressure_x)
        pressure2 = self.pressure2(pressure1).unsqueeze(2)

        coldh_x = data['coldh_x'].squeeze(2)
        coldh1 = self.coldh1(coldh_x)
        coldh2 = self.coldh2(coldh1).unsqueeze(2)

        hoth_x = data['hoth_x'].squeeze(2)
        hoth1 = self.hoth1(hoth_x)
        hoth2 = self.hoth2(hoth1).unsqueeze(2)

        hotzhishu_x = data['hotzhishu_x'].squeeze(2)
        hotzhishu1 = self.hotzhishu1(hotzhishu_x)
        hotzhishu2 = self.hotzhishu2(hotzhishu1).unsqueeze(2)

        coldzhishu_x = data['coldzhishu_x'].squeeze(2)
        coldzhishu1 = self.coldzhishu1(coldzhishu_x)
        coldzhishu2 = self.coldzhishu2(coldzhishu1).unsqueeze(2)

        fengspeed_x = data['fengspeed_x'].squeeze(2)
        fengspeed1 = self.fengspeed1(fengspeed_x)
        fengspeed2 = self.fengspeed2(fengspeed1).unsqueeze(2)

        # 假设 电负荷： 温度  热指数   冷指数  风速    压力
        #    冷负荷： 温度  冷缺小时  冷指数  风速    压力
        #    热负荷： 温度  加热小时  热指数  风速    压力

        # 电负荷特征拼接
        Aele = torch.cat([wendu2, hotzhishu2, coldzhishu2, pressure2, fengspeed2], dim=2)  # 5维度
        eleqixiang = self.F1(Aele, dim=2)
        Aeleload = torch.mul(eleqixiang, eleload_x).transpose(1, 2)  # 输出近邻特征的接口
        # 冷负荷特征拼接
        Acold = torch.cat([wendu2, coldh2, coldzhishu2, fengspeed2, pressure2], dim=2)  # 5维度
        coldqixiang = self.F2(Acold, dim=2)
        Acoldload = torch.mul(coldqixiang, coldload_x).transpose(1, 2)  # 输出近邻特征的接口
        # 热负荷特征拼接
        Ahot = torch.cat([wendu2, hoth2, hotzhishu2, fengspeed2, pressure2], dim=2)  # 5维度
        hotqixiang = self.F3(Ahot, dim=2)
        Ahotload = torch.mul(hotqixiang, hotload_x).transpose(1, 2)  # 输出近邻特征的接口      128 5 8

        # output_ele,_ = self.lstm_ele(Aeleload.transpose(1, 2))
        # output_cold,_ = self.lstm_cold(Acoldload.transpose(1, 2))
        # output_hot,_ = self.lstm_hot(Ahotload.transpose(1, 2))
        output_ele = self.lstm_ele(Aeleload.transpose(1, 2))
        output_cold = self.lstm_cold(Acoldload.transpose(1, 2))
        output_hot = self.lstm_hot(Ahotload.transpose(1, 2))

        test = torch.cat((output_ele, output_cold, output_hot), 1)

        output = self.skiplstm(test)

        preds = []

        # pred1, pred2, pred3 = self.fc1(output[0][:, 0, :]), self.fc2(output[0][:, 1, :]), self.fc3(
        #     output[0][:, 2, :])
        pred1, pred2, pred3 = output[0][:, [0], :], output[0][:, [1], :], output[0][:, [2], :]
        #pred1, pred2, pred3 = self.conv1(pred1), self.conv2(pred2), self.conv3(pred3)
        # pred = torch.stack([pred1, pred2, pred3], dim=0)

        out = {'pred1': pred1, 'pred2': pred2, 'pred3': pred3}

        return out


def main():
    os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
    # Loading Dataset
    train_data = LoadData(data_path=["data/6666.mat"], divide_points=[700, 176],
                          history_length=8, train_mode="train")
    train_loader = DataLoader(train_data, batch_size=128, shuffle=False)
    test_data = LoadData(data_path=["data/6666.mat"], divide_points=[700, 176],
                         history_length=8, train_mode="test")
    test_loader = DataLoader(test_data, batch_size=128, shuffle=False)

    # Loading Model
    my_net = MSADNN()
    my_net = torch.nn.DataParallel(my_net)
    my_net = my_net.to(device)
    criterion1 = nn.MSELoss()
    criterion2 = nn.L1Loss()
    optimizer = optim.Adam(lr=0.005, params=my_net.parameters())
    torch.backends.cudnn.enabled = False

    # Train mode
    Epoch = 500

    my_net.train()
    for epoch in range(Epoch):
        epoch_loss = 0.0
        start_time = time.time()
        for data in train_loader:
            my_net.zero_grad()

            predict_value11 = my_net(data)['pred1'].to(torch.device("cpu"))
            predict_value12 = my_net(data)['pred2'].to(torch.device("cpu"))
            predict_value13 = my_net(data)['pred3'].to(torch.device("cpu"))

            loss11 = criterion1(predict_value11, data["eleload_y"])
            loss12 = criterion1(predict_value12, data["coldload_y"])
            loss13 = criterion1(predict_value13, data["hotload_y"])
            loss = (loss11 + loss12 + loss13) / 3

            epoch_loss += loss.item()
            loss.backward()
            optimizer.step()
        end_time = time.time()
        print(epoch_loss)
        print("Epoch: {:04d}, Loss: {:02.7f}, time:{:02.4f}".format(epoch, epoch_loss, end_time - start_time))

        my_net.eval()
        with torch.no_grad():
            total_loss = 0.0

            for data in test_loader:
                predict_value21 = my_net(data)['pred1'].to(torch.device("cpu"))  # [B, N, 1, D]
                predict_value22 = my_net(data)['pred2'].to(torch.device("cpu"))
                predict_value23 = my_net(data)['pred3'].to(torch.device("cpu"))

                target_value21 = data["eleload_y"].to(torch.device("cpu"))
                target_value22 = data["coldload_y"].to(torch.device("cpu"))
                target_value23 = data["hotload_y"].to(torch.device("cpu"))

                # loss1 = criterion1(predict_value, data["flow_y"])

                loss21 = criterion2(predict_value21, data["eleload_y"])
                loss22 = criterion2(predict_value22, data["coldload_y"])
                loss23 = criterion2(predict_value23, data["hotload_y"])
                loss2 = (loss21 + loss22 + loss23) / 3

                # print("loss2:{:02.4f}".format(loss2))
                total_loss += loss2.item()
                total_loss = total_loss

                Predict21 = predict_value21.squeeze(2).numpy()
                Predict22 = predict_value22.squeeze(2).numpy()
                Predict23 = predict_value23.squeeze(2).numpy()

                Target21 = target_value21.squeeze(2).numpy()
                Target22 = target_value22.squeeze(2).numpy()
                Target23 = target_value23.squeeze(2).numpy()

            elea = (37461.63 - 3470.17) * Predict21.reshape(-1, 1) + 3740.17
            eleb = (37461.63 - 3470.17) * Target21.reshape(-1, 1) + 3470.17
            mae1 = np.mean(np.abs(elea - eleb))
            mape1 = np.mean(np.abs((elea - eleb) / eleb))
            rmse1 = np.sqrt(np.mean(np.power(elea - eleb, 2)))

            colda = (69546.2 - 27.254) * Predict22.reshape(-1, 1) + 27.254
            coldb = (69546.2 - 27.254) * Target22.reshape(-1, 1) + 27.254
            mae2 = np.mean(np.abs(colda - coldb))
            mape2 = np.mean(np.abs((colda - coldb) / coldb))
            rmse2 = np.sqrt(np.mean(np.power(colda - coldb, 2)))

            hota = (4585.294 - 5.882) * Predict23.reshape(-1, 1) + 5.882
            hotb = (4585.294 - 5.882) * Target23.reshape(-1, 1) + 5.882
            mae3 = np.mean(np.abs(hota - hotb))
            mape3 = np.mean(np.abs((hota - hotb) / hotb))
            rmse3 = np.sqrt(np.mean(np.power(hota - hotb, 2)))

            end_time = time.time()

            print("elemae:{:02.4f}, mape:{:02.4f}, rmse:{:02.4f}, time:{:02.4f}".format(mae1, mape1, rmse1,
                                                                                        end_time - start_time))
            print("coldmae:{:02.4f}, mape:{:02.4f}, rmse:{:02.4f}".format(mae2, mape2, rmse2, ))

            print("hotmae:{:02.4f}, mape:{:02.4f}, rmse:{:02.4f}".format(mae3, mape3, rmse3, ))

    plt.plot(elea, c='b', marker='.', label='电预测')
    plt.plot(eleb, c='r', marker='.', label='电实际')
    plt.plot(colda, c='b', marker='D', label='冷预测')
    plt.plot(coldb, c='r', marker='D', label='冷实际')
    plt.plot(hota, c='b', marker='2', label='热预测')
    plt.plot(hotb, c='r', marker='2', label='热实际')
    plt.legend()
    plt.show()

    # elea=elea.tolist()
    # eleb=eleb.tolist()
    # colda=colda.tolist()
    # coldb=coldb.tolist()
    # hota=hota.tolist()
    # hotb=hotb.tolist()
    #
    # import xlwt
    # file = xlwt.Workbook('encoding = utf-8')
    # sheet1 = file.add_sheet('sheet1', cell_overwrite_ok=True)
    # sheet1.write(0, 0, "电预测")  # 第1行第3列
    # sheet1.write(0, 1, "电实际")  # 第1行第4列
    # sheet1.write(0, 2, "冷预测")  # 第1行第5列
    # sheet1.write(0, 3, "冷实际")  # 第1行第5列
    # sheet1.write(0, 4, "热预测")  # 第1行第5列
    # sheet1.write(0, 5, "热实际")  # 第1行第5列
    # sheet1.write(0, 6, "mae")  # 第1行第5列
    # sheet1.write(0, 7, "mape")  # 第1行第5列
    # sheet1.write(0, 8, "rmse")  # 第1行第5列
    # for i in range(len(elea)):
    #     sheet1.write(i + 1, 0, elea[i][0])
    #     sheet1.write(i + 1, 1, eleb[i][0])
    #     sheet1.write(i + 1, 2, colda[i][0])
    #     sheet1.write(i + 1, 3, coldb[i][0])
    #     sheet1.write(i + 1, 4, hota[i][0])
    #     sheet1.write(i + 1, 5, hotb[i][0])
    # sheet1.write(1, 6, mae1)
    # sheet1.write(1, 7, mape1)
    # sheet1.write(1, 8, rmse1)
    # sheet1.write(2, 6, mae2)
    # sheet1.write(2, 7, mape2)
    # sheet1.write(2, 8, rmse2)
    # sheet1.write(3, 6, mae3)
    # sheet1.write(3, 7, mape3)
    # sheet1.write(3, 8, rmse3)
    # file.save('data/123.xls')

if __name__ == '__main__':
    main()
